#include <stdio.h>
int main() {
	char nome[100];
	float valorCompra;
	float bonus;
	int i;
	for (i = 1; i <= 150; i++) {
		printf("Digite o nome do cliente %d: ", i);
		scanf(" %[^\n]", nome);
		printf("Digite o valor das compras no ano passado do cliente %d: ", i);
		scanf("%f", &valorCompra);
		if (valorCompra < 500000) {
			bonus = valorCompra * 0.10;
		} else {
			bonus = valorCompra * 0.15;
		}
		printf("Cliente: %s - Bônus: R$ %.2f\n\n", nome, bonus);
	}
	return 0;
}
