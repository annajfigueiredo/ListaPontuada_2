#include <stdio.h>
int main() {
	int a, b;
	int i;
	int count = 0;
	while (count < 5) {
		scanf("%d %d", &a, &b);
		if (a < b && a > 0 && b > 0) {
			i = a;
			while (i <= b) {
				if (i % 2 == 0) {
					printf("%d ", i);
				}
				i = i + 1;
			}
			printf("\n");
			count = count + 1;
		} else {
			printf("Digite valores positivos e com a < b\n");
		}
	}
	return 0;
}