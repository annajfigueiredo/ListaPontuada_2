#include <stdio.h>

int bissexto(int ano) {
    return (ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0);
}

int dias_no_mes(int mes, int ano) {
    int dias_por_mes[] = {31, 28, 31, 30, 31, 30,
                          31, 31, 30, 31, 30, 31};
    if (mes == 2 && bissexto(ano)) {
        return 29;
    }
    return dias_por_mes[mes - 1];
}

int contar_dias(int dia, int mes, int ano) {
    int total_dias = dia;
    for (int i = 0; i < ano; i++) {
        if (bissexto(i)) {
            total_dias += 366;
        } else {
            total_dias += 365;
        }
    }
    for (int i = 1; i < mes; i++) {
        total_dias += dias_no_mes(i, ano);
    }
    return total_dias;
}

int main() {
    int dia1, mes1, ano1;
    int dia2, mes2, ano2;
    printf("Digite a primeira data (dia mes ano): ");
    scanf("%d %d %d", &dia1, &mes1, &ano1);
    printf("Digite a segunda data (dia mes ano): ");
    scanf("%d %d %d", &dia2, &mes2, &ano2);
    
    int dias1 = contar_dias(dia1, mes1, ano1);
    int dias2 = contar_dias(dia2, mes2, ano2);
    int diferenca;
    
    if (dias1 > dias2) {
        diferenca = dias1 - dias2;
    } else {
        diferenca = dias2 - dias1;
    }
    
    printf("A diferença entre as datas é de %d dias.\n", diferenca);
    return 0;
}
