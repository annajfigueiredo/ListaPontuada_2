#include <stdio.h>

int main() {
    char sexo, olhos, cabelo;
    int idade;

    do {
        scanf(" %c", &sexo);
        scanf(" %c", &olhos);
        scanf(" %c", &cabelo);
        scanf("%d", &idade);
        
        if (idade < 0) break;
        
        printf("%c %c %c %d\n", sexo, olhos, cabelo, idade);
    } while (1);

    return 0;
}
