#include <stdio.h>

int main() {
    int i = 0;
    int valor;
    int maior = 0;
    int menor = 0;
    long soma = 0;

    while (i < 500) {
        scanf("%d", &valor);
        
        if (valor <= 0) {
            printf("Digite um valor inteiro e positivo.\n");
            continue;
        }

        if (i == 0) {
            maior = valor;
            menor = valor;
        } else {
            if (valor > maior) {
                maior = valor;
            }
            if (valor < menor) {
                menor = valor;
            }
        }
        
        soma += valor;
        i++;
    }

    printf("Maior valor: %d\n", maior);
    printf("Menor valor: %d\n", menor);
    printf("Média: %.2f\n", (float)soma / 500);
    
    return 0;
}
