#include <stdio.h>
int main() {
	int valor;
	int soma = 0;
	int total = 0;
	int positivos = 0;
	int negativos = 0;
	float media;
	float percPos, percNeg;
	printf("Digite um numero (0 para parar): ");
	scanf("%d", &valor);
	while (valor != 0) {
		soma = soma + valor;
		total = total + 1;
		if (valor > 0) {
			positivos = positivos + 1;
		} else {
			negativos = negativos + 1;
		}
		printf("Digite um numero (0 para parar): ");
		scanf("%d", &valor);
	}
	if (total > 0) {
		media = (float)soma / total;
		percPos = (float)positivos * 100 / total;
		percNeg = (float)negativos * 100 / total;
		printf("\nMedia = %.2f\n", media);
		printf("Quantidade positivos = %d\n", positivos);
		printf("Quantidade negativos = %d\n", negativos);
		printf("Percentual positivos = %.2f%%\n", percPos);
		printf("Percentual negativos = %.2f%%\n", percNeg);
	} else {
		printf("\nNenhum numero foi digitado.\n");
	}
	return 0;
}
