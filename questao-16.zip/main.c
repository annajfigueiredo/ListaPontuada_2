#include <stdio.h>
int calcRaiz(int n) {
	int i = 0;
	while (i * i <= n) {
		i = i + 1;
	}
	return i - 1;
}
int main() {
	int count = 0;
	int num;
	printf("Digite numeros (negativo para parar): ");
	while (1) {
		scanf("%d", &num);
		if (num < 0) {
			break;
		}
		if (count % 20 == 0) {
			printf("\nValor Quadrado Cubo Raiz\n");
		}
		printf("%d %d %d %d\n", num, num*num, num*num*num, calcRaiz(num));
		count = count + 1;
	}
	printf("\nFim do programa.\n");
	return 0;
}
