#include <stdio.h>

int main() {
    int sexo, idade;
    float altura;
    int somaIdade = 0, somaIdadeHomens = 0, contHomens = 0;
    float somaAlturaMulheres = 0;
    int contMulheres = 0;
    int contIdade1835 = 0;
    int i = 1;

    do {
        printf("Pessoa %d\n", i);
        printf("Sexo (0-feminino, 1-masculino): ");
        scanf("%d", &sexo);
        printf("Idade: ");
        scanf("%d", &idade);
        printf("Altura: ");
        scanf("%f", &altura);

        somaIdade += idade;

        if (sexo == 0) {
            somaAlturaMulheres += altura;
            contMulheres++;
        } else {
            somaIdadeHomens += idade;
            contHomens++;
        }

        if (idade >= 18 && idade <= 35) {
            contIdade1835++;
        }

        i++;
        printf("\n");
    } while (i <= 1000);

    printf("Média idade do grupo: %.2f\n", (float)somaIdade / 1000);
    
    if (contMulheres > 0) {
        printf("Média altura das mulheres: %.2f\n", somaAlturaMulheres / contMulheres);
    } else {
        printf("Nenhuma mulher cadastrada.\n");
    }

    if (contHomens > 0) {
        printf("Média idade dos homens: %.2f\n", (float)somaIdadeHomens / contHomens);
    } else {
        printf("Nenhum homem cadastrado.\n");
    }

    printf("Percentual de pessoas entre 18 e 35 anos: %.2f%%\n", ((float)contIdade1835 / 1000) * 100);

    return 0;
}
