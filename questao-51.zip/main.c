#include <stdio.h>
int main() {
	int num;
	int fatorial = 1;
	int contador = 1;
	do {
		printf("Digite um numero inteiro: ");
		scanf("%d", &num);
		if (num < 0) {
			printf("Numero invalido! Tente novamente.\n");
		}
	} while (num < 0);
	while (contador <= num) {
		fatorial = fatorial * contador;
		contador = contador + 1;
	}
	printf("O fatorial de %d e %d\n", num, fatorial);
	return 0;
}
