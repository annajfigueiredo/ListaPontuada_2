#include <stdio.h>
int main() {
	int X, i;
	int potencia;
	printf("Digite o valor de X: ");
	scanf("%d", &X);
	for (i = 1; i <= 4; i++) {
		printf("1 ");
	}
	potencia = X;
	for (i = 5; i <= 20; i++) {
		printf("%d ", potencia);
		potencia = potencia * X;
	}
	printf("\n");
	return 0;
}
