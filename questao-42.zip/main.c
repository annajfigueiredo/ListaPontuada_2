#include <stdio.h>

int main() {
    int n, H;

    printf("Digite um número inteiro positivo: ");
    scanf("%d", &n);

    if (n > 0) {
        H = n * 10;
        printf("O resultado da soma H é: %d\n", H);
    } else {
        printf("Por favor, insira um número inteiro positivo.\n");
    }

    return 0;
}
