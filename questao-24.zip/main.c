#include <stdio.h>

int main() {
    char sexo, olhos, cabelo;
    int idade;
    int maiorIdade = 0;
    int qtdMulher = 0;

    do {
        printf("Digite o sexo (F/M), olhos (V/A), cabelo (L/C) e idade (ou -1 para sair):\n");
        scanf(" %c", &sexo);
        
        if (sexo == 'F' || sexo == 'f' || sexo == 'M' || sexo == 'm') {
            scanf(" %c", &olhos);
            scanf(" %c", &cabelo);
            scanf("%d", &idade);
        } else {
            printf("Sexo inválido. Tente novamente.\n");
            continue;
        }

        if (idade == -1) break;

        if (idade > maiorIdade) {
            maiorIdade = idade;
        }

        if ((sexo == 'F' || sexo == 'f') && idade >= 18 && idade <= 35 && (olhos == 'V' || olhos == 'v') && (cabelo == 'L' || cabelo == 'l')) {
            qtdMulher++;
        }
    } while (1);

    printf("Maior idade: %d\n", maiorIdade);
    printf("Quantidade de mulheres: %d\n", qtdMulher);
    
    return 0;
}
