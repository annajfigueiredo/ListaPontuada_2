#include <stdio.h>

int main() {
    int i, num, num_alto, num_baixo;
    int altura, altura_alta, altura_baixa;

    altura_alta = 0;
    altura_baixa = 1000;

    for (i = 0; i < 5; i++) {
        printf("Digite o número do aluno e a altura em cm (ex: 1 170): ");
        scanf("%d %d", &num, &altura);
        
        if (i == 0) {
            altura_alta = altura;
            altura_baixa = altura;
            num_alto = num;
            num_baixo = num;
        } else {
            if (altura > altura_alta) {
                altura_alta = altura;
                num_alto = num;
            }
            if (altura < altura_baixa) {
                altura_baixa = altura;
                num_baixo = num;
            }
        }
    }

    printf("Aluno mais alto: %d, altura: %d cm\n", num_alto, altura_alta);
    printf("Aluno mais baixo: %d, altura: %d cm\n", num_baixo, altura_baixa);
    
    return 0;
}
