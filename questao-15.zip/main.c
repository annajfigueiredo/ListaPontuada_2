#include <stdio.h>
int main() {
	int numero;
	int grupo1 = 0;
	int grupo2 = 0;
	int grupo3 = 0;
	int grupo4 = 0;
	printf("Digite números (digite um número negativo para terminar): ");
	scanf("%d", &numero);
	while (numero >= 0) {
		if (numero <= 25) {
			grupo1 = grupo1 + 1;
		} else if (numero <= 50) {
			grupo2 = grupo2 + 1;
		} else if (numero <= 75) {
			grupo3 = grupo3 + 1;
		} else if (numero <= 100) {
			grupo4 = grupo4 + 1;
		}
		printf("Digite números (digite um número negativo para terminar): ");
		scanf("%d", &numero);
	}
	printf("\nQuantidade de números em cada grupo:\n");
	printf("De 0 a 25: %d\n", grupo1);
	printf("De 26 a 50: %d\n", grupo2);
	printf("De 51 a 75: %d\n", grupo3);
	printf("De 76 a 100: %d\n", grupo4);
	return 0;
}
