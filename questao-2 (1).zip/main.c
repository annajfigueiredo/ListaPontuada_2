/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


int main() { 
    int N, i, j; 
    float E = 1.0f;    
    float fatorial; 
 
    do { 
        printf("Digite um valor inteiro para N: "); 
        scanf("%d", &N); 
 
        if (N <= 0) { 
            printf("Valor invalido! Tente novamente.\n"); 
        } 
    } while (N <= 0); 
 
    for (i = 1; i <= N; i++) { 
        fatorial = 1.0f; 
        for (j = 1; j <= i; j++) { 
            fatorial = fatorial * j; 
        } 
 
        E = E + (1.0f / fatorial); 
    } 
    printf("O valor de E para N = %d eh: %f\n", N, E); 
return 0; 
}
