#include <stdio.h>
int main() {
	int codigo;
	float n1, n2, n3, media;
	printf("Digite o codigo do aluno (negativo para sair): ");
	scanf("%d", &codigo);
	while (codigo >= 0) {
		printf("Digite as 3 notas:\n");
		scanf("%f", &n1);
		scanf("%f", &n2);
		scanf("%f", &n3);
		if (n1 >= n2 && n1 >= n3) {
			media = (n1 * 4 + n2 * 3 + n3 * 3) / 10;
		} else if (n2 >= n1 && n2 >= n3) {
			media = (n2 * 4 + n1 * 3 + n3 * 3) / 10;
		} else {
			media = (n3 * 4 + n1 * 3 + n2 * 3) / 10;
		}
		printf("Aluno %d - Media: %.2f - ", codigo, media);
		if (media >= 5) {
			printf("APROVADO\n\n");
		} else {
			printf("REPROVADO\n\n");
		}
		printf("Digite o codigo do aluno (negativo para sair): ");
		scanf("%d", &codigo);
	}
	return 0;
}