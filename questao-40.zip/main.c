#include <stdio.h>

int main() {
    int n, i, m, j;
    int soma, fatorial;

    printf("Digite quantos valores você deseja ler: ");
    scanf("%d", &n);

    for (i = 1; i <= n; i++) {
        printf("Digite um valor inteiro positivo: ");
        scanf("%d", &m);

        if (m < 0) {
            printf("Por favor, insira um valor inteiro positivo.\n");
            i--; // Decrementa i para repetir a leitura
            continue; // Pula para a próxima iteração do loop
        }

        soma = 0;
        fatorial = 1;

        for (j = 1; j <= m; j++) {
            soma += j;
            fatorial *= j;
        }

        printf("Valor: %d | Soma: %d | Fatorial: %d\n", m, soma, fatorial);
    }

    return 0;
}
