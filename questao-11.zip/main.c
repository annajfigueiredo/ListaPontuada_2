#include <stdio.h>
int main() {
	int n, a1, r, termo, i, soma = 0;
	printf("Digite a quantidade de termos (n): ");
	scanf("%d", &n);
	printf("Digite o primeiro termo (a1): ");
	scanf("%d", &a1);
	printf("Digite a razao (r): ");
	scanf("%d", &r);
	printf("\nTermos da PA:\n");
	for (i = 0; i < n; i++) {
		termo = a1 + i * r;
		printf("%d ", termo);
		soma = soma + termo;
	}
	printf("\n\nSoma dos termos = %d\n", soma);
	return 0;
}

