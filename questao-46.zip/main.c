#include <stdio.h>
int main() {
	char sexo, olhos, cabelos;
	int idade, i, maiorIdade = 0, qtdMulheres = 0;
	for(i = 1; i <= 500; i++) {
		printf("Sexo (M/F): ");
		scanf(" %c", &sexo);
		printf("Olhos (A/V/C): ");
		scanf(" %c", &olhos);
		printf("Cabelos (L/C/P): ");
		scanf(" %c", &cabelos);
		printf("Idade: ");
		scanf("%d", &idade);
		if(idade > maiorIdade) {
			maiorIdade = idade;
		}
		if(sexo == 'F' && idade >= 18 && idade <= 35 && olhos == 'V' && cabelos == 'L') {
			qtdMulheres = qtdMulheres + 1;
		}
	}
	printf("Maior idade: %d\n", maiorIdade);
	printf("Quantidade de mulheres com olhos verdes e cabelos louros entre 18 e 35: %d\n", qtdMulheres);
	return 0;
}
