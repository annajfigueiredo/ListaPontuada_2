#include <stdio.h>
int main() {
	int numero, soma = 0, quantidade = 0;
	float media;
	printf("Digite numeros (0 para encerrar):\n");
	scanf("%d", &numero);
	while (numero != 0) {
		if (numero % 2 == 0) {
			soma = soma + numero;
			quantidade = quantidade + 1;
		}
		scanf("%d", &numero);
	}
	if (quantidade > 0) {
		media = (float)soma / quantidade;
		printf("Media dos numeros pares = %.2f\n", media);
	} else {
		printf("Nenhum numero par foi digitado.\n");
	}
	return 0;
}
