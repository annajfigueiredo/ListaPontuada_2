#include <stdio.h>
int main() {
	int i = 0;
	int valor;
	int dentro = 0;
	int fora = 0;
	while (i < 10) {
		scanf("%d", &valor);
		if (valor >= 10 && valor <= 20) {
			dentro = dentro + 1;
		} else {
			fora = fora + 1;
		}
		i = i + 1;
	}
	printf("Dentro do intervalo: %d\n", dentro);
	printf("Fora do intervalo: %d\n", fora);
	return 0;
}
