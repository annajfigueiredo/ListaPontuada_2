#include <stdio.h>
int main() {
	int valor;
	int soma = 0;
	int quantidade = 0;
	float media;
	printf("Digite numeros positivos (digite um numero negativo para encerrar):\n");
	do {
		scanf("%d", &valor);
		if (valor >= 0) {
			soma = soma + valor;
			quantidade = quantidade + 1;
		}
	} while (valor >= 0);
	if (quantidade > 0) {
		media = (float)soma / quantidade;
		printf("A media dos %d valores positivos eh: %f\n", quantidade, media);
	} else {
		printf("Nenhum valor positivo foi digitado.\n");
	}
	return 0;
}
