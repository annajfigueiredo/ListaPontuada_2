#include <stdio.h>

int main() {
    int count = 3;
    int num = 4;
    int i, primo;

    printf("1\n2\n3\n");

    while(count < 20) {
        primo = 1;
        
        for(i = 2; i < num; i++) {
            if(num % i == 0) {
                primo = 0;
                break;
            }
        }
        
        if(primo) {
            printf("%d\n", num);
            count++;
        }
        
        num++;
    }

    return 0;
}
