#include <stdio.h>
int main() {
	int i = 1;
	int codigoCidade;
	char estado[3];
	int numVeiculos;
	int numAcidentes;
	int maiorAcidente = -1;
	int menorAcidente = 1000000;
	int codigoMaior = 0;
	int codigoMenor = 0;
	long somaVeiculos = 0;
	int somaAcidentesRS = 0;
	int contRS = 0;
	while (i <= 200) {
		printf("Cidade %d\n", i);
		printf("Codigo da cidade: ");
		scanf("%d", &codigoCidade);
		printf("Estado: ");
		scanf("%s", estado);
		printf("Numero de veiculos: ");
		scanf("%d", &numVeiculos);
		printf("Numero de acidentes: ");
		scanf("%d", &numAcidentes);
		somaVeiculos = somaVeiculos + numVeiculos;
		if (numAcidentes > maiorAcidente) {
			maiorAcidente = numAcidentes;
			codigoMaior = codigoCidade;
		}
		if (numAcidentes < menorAcidente) {
			menorAcidente = numAcidentes;
			codigoMenor = codigoCidade;
		}
		if (estado[0] == 'R' && estado[1] == 'S') {
			somaAcidentesRS = somaAcidentesRS + numAcidentes;
			contRS = contRS + 1;
		}
		i = i + 1;
		printf("\n");
	}
	printf("Maior numero de acidentes: %d na cidade codigo %d\n", maiorAcidente, codigoMaior);
	printf("Menor numero de acidentes: %d na cidade codigo %d\n", menorAcidente, codigoMenor);
	printf("Media de veiculos nas cidades: %.2f\n", (float)somaVeiculos / 200);
	if (contRS > 0) {
		printf("Media de acidentes no RS: %.2f\n", (float)somaAcidentesRS / contRS);
	} else {
		printf("Nenhuma cidade do RS informada.\n");
	}
	return 0;
}
