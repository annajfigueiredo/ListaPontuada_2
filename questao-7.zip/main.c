#include <stdio.h>
int main() {
	int codigo;
	float n1, n2, n3, media;
	printf("Digite o codigo do aluno (0 para sair): ");
	scanf("%d", &codigo);
	while (codigo != 0) {
		printf("Digite as 3 notas:\n");
		scanf("%f", &n1);
		scanf("%f", &n2);
		scanf("%f", &n3);
		media = (n1 + n2 + n3) / 3;
		printf("Media do aluno %d = %.2f\n\n", codigo, media);
		printf("Digite o codigo do proximo aluno (0 para sair): ");
		scanf("%d", &codigo);
	}
	return 0;
}
