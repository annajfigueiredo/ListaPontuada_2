#include <stdio.h>
int main() {
	int num = 1;
	int soma, i;
	int achou = 0;
	while (achou < 5) {
		soma = 0;
		for (i = 1; i < num; i++) {
			if (num % i == 0) {
				soma = soma + i;
			}
		}
		if (soma == num) {
			printf("%d\n", num);
			achou = achou + 1;
		}
		num = num + 1;
	}
	return 0;
}