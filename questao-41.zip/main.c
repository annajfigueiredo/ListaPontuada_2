#include <stdio.h>
int main() {
	int i;
	float n1, n2, n3, media, somaTurma = 0;
	for (i = 1; i <= 50; i++) {
		printf("Notas do aluno %d:\n", i);
		scanf("%f", &n1);
		scanf("%f", &n2);
		scanf("%f", &n3);
		media = (n1 * 2 + n2 * 4 + n3 * 3) / 10;
		printf("Media: %.2f - ", media);
		if (media >= 7) {
			printf("Aprovado\n");
		} else {
			printf("Reprovado\n");
		}
		somaTurma = somaTurma + media;
	}
	printf("Media geral da turma: %.2f\n", somaTurma / 50);
	return 0;
}