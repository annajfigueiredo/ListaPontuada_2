#include <stdio.h>
int main() {
	int m, n, i, soma;
	printf("Digite pares m e n (inteiros positivos). Para parar, digite zero ou negativo.\n");
	do {
		printf("Digite m: ");
		scanf("%d", &m);
		printf("Digite n: ");
		scanf("%d", &n);
		if (m > 0 && n > 0) {
			soma = 0;
			for (i = 0; i < n; i++) {
				soma = soma + (m + i);
			}
			printf("Soma dos %d numeros consecutivos a partir de %d = %d\n\n", n, m, soma);
		}
	} while (m > 0 && n > 0);
	printf("Programa encerrado.\n");
	return 0;
}
