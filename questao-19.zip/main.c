#include <stdio.h>
int main() {
	int num;
	int par = 0, impar = 0, total = 0;
	int somaPar = 0, somaTotal = 0;
	printf("Digite numeros positivos (0 para parar):\n");
	do {
		printf("Digite um numero: ");
		scanf("%d", &num);
		if (num > 0) {
			total = total + 1;
			somaTotal = somaTotal + num;
			if (num % 2 == 0) {
				par = par + 1;
				somaPar = somaPar + num;
			} else {
				impar = impar + 1;
			}
		} else if (num < 0) {
			printf("Digite apenas numeros positivos ou zero para parar.\n");
		}
	} while (num != 0);
	if (total > 0) {
		float mediaPar = 0.0, mediaGeral = 0.0;
		if (par > 0) {
			mediaPar = (float)somaPar / par;
		}
		mediaGeral = (float)somaTotal / total;
		printf("\nQuantidade de numeros pares: %d\n", par);
		printf("Quantidade de numeros impares: %d\n", impar);
		printf("Media dos numeros pares: %.2f\n", mediaPar);
		printf("Media geral dos numeros lidos: %.2f\n", mediaGeral);
	} else {
		printf("Nenhum numero valido foi digitado.\n");
	}
	printf("Fim do programa.\n");
	return 0;
}