#include <stdio.h>
int main() {
	int valores[5][4];
	int i, j, k, temp;
	for (i = 0; i < 5; i++) {
		for (j = 0; j < 4; j++) {
			scanf("%d", &valores[i][j]);
		}
	}
	for (i = 0; i < 5; i++) {
		for (j = 0; j < 4; j++) {
			printf("%d ", valores[i][j]);
		}
		printf("\n");
	}
	for (i = 0; i < 5; i++) {
		for (j = 0; j < 3; j++) {
			for (k = j + 1; k < 4; k++) {
				if (valores[i][j] < valores[i][k]) {
					temp = valores[i][j];
					valores[i][j] = valores[i][k];
					valores[i][k] = temp;
				}
			}
		}
	}
	for (i = 0; i < 5; i++) {
		for (j = 0; j < 4; j++) {
			printf("%d ", valores[i][j]);
		}
		printf("\n");
	}
	return 0;
}
