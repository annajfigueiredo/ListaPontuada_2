#include <stdio.h>
int main() {
	int n, i, j, valor, fatorial;
	printf("Quantos valores serao lidos? ");
	scanf("%d", &n);
	printf("\nValor\tFatorial\n");
	for (i = 1; i <= n; i++) {
		printf("Digite o valor %d: ", i);
		scanf("%d", &valor);
		fatorial = 1;
		for (j = 1; j <= valor; j++) {
			fatorial = fatorial * j;
		}
		printf("%d\t%d\n", valor, fatorial);
	}
	return 0;
}
