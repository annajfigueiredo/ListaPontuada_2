#include <stdio.h>
int main() {
	int num;
	int somaNeg = 0;
	printf("Digite numeros inteiros (0 para parar):\n");
	do {
		printf("Digite um numero: ");
		scanf("%d", &num);
		if (num < 0) {
			somaNeg = somaNeg + num;
		}
	} while (num != 0);
	printf("\nSomatorio dos numeros negativos = %d\n", somaNeg);
	
	return 0;
}
