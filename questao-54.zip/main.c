#include <stdio.h>
int main() {
	float num1, num2;
	float menor, maior;
	float intervalo, parte;
	float ponto1, ponto2;
	do {
		printf("Digite dois números diferentes:\n");
		printf("Primeiro número: ");
		scanf("%f", &num1);
		printf("Segundo número: ");
		scanf("%f", &num2);
		if (num1 == num2) {
			printf("Os números não podem ser iguais! Tente novamente.\n\n");
		}
	} while (num1 == num2);
	if (num1 < num2) {
		menor = num1;
		maior = num2;
	} else {
		menor = num2;
		maior = num1;
	}
	intervalo = maior - menor;
	parte = intervalo / 3;
	ponto1 = menor + parte;
	ponto2 = menor + 2 * parte;
	printf("\nO intervalo entre %.2f e %.2f foi dividido em 3 partes iguais.\n", menor, maior);
	printf("Ponto 1: %.2f\n", ponto1);
	printf("Ponto 2: %.2f\n", ponto2);
	return 0;
}
