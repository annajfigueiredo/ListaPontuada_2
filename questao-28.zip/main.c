#include <stdio.h>
int main() {
	int n, i = 1;
	float soma = 0;
	scanf("%d", &n);
	while (i <= n) {
		printf("1/%d = %.2f\n", i, 1.0 / i);
		soma = soma + 1.0 / i;
		i = i + 1;
	}
	printf("Soma = %.2f\n", soma);
	return 0;
}