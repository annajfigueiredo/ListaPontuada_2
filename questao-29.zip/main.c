#include <stdio.h>
int main() {
	int n, soma = 0, count = 0;
	printf("Digite números (digite um número fora de 13 a 73 para parar):\n");
	while (1) {
		scanf("%d", &n);
		if (n < 13 || n > 73) {
			break;
		}
		soma = soma + n;
		count = count + 1;
	}
	if (count > 0) {
		printf("Media = %.2f\n", (float)soma / count);
	} else {
		printf("Nenhum número válido foi digitado.\n");
	}
	return 0;
}