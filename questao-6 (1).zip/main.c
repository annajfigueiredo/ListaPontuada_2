#include <stdio.h>

int main() {
    int voto;
    int c1 = 0, c2 = 0, c3 = 0, c4 = 0;
    int nulos = 0, brancos = 0;

    printf("Contagem de Votos da Eleicao\n");

    while(1) {
        printf("Informe o voto (1-4 candidatos, 5 nulo, 6 branco, 0 sair): ");
        scanf("%d", &voto);

        if(voto == 0) break;
        
        if(voto == 1) c1++;
        else if(voto == 2) c2++;
        else if(voto == 3) c3++;
        else if(voto == 4) c4++;
        else if(voto == 5) nulos++;
        else if(voto == 6) brancos++;
        else printf("Codigo invalido!\n");
    }

    printf("\nTotal de votos:\n");
    printf("Candidato 1: %d\n", c1);
    printf("Candidato 2: %d\n", c2);
    printf("Candidato 3: %d\n", c3);
    printf("Candidato 4: %d\n", c4);
    printf("Nulos: %d\n", nulos);
    printf("Brancos: %d\n", brancos);

    return 0;
}
