#include <stdio.h>
int main() {
	int i, sexo;
	float altura;
	float maior, menor;
	float somaMulher = 0;
	int qtdMulher = 0;
	float somaTudo = 0;
	printf("Altura da pessoa 1: ");
	scanf("%f", &altura);
	printf("Sexo da pessoa 1 (1-masc, 2-fem): ");
	scanf("%d", &sexo);
	maior = altura;
	menor = altura;
	somaTudo = altura;
	if (sexo == 2) {
		somaMulher = altura;
		qtdMulher = 1;
	}
	for (i = 2; i <= 50; i++) {
		printf("Altura da pessoa %d: ", i);
		scanf("%f", &altura);
		printf("Sexo da pessoa %d (1-masc, 2-fem): ", i);
		scanf("%d", &sexo);
		if (altura > maior) {
			maior = altura;
		}
		if (altura < menor) {
			menor = altura;
		}
		somaTudo = somaTudo + altura;
		if (sexo == 2) {
			somaMulher = somaMulher + altura;
			qtdMulher = qtdMulher + 1;
		}
	}
	printf("\nMaior altura: %.2f\n", maior);
	printf("Menor altura: %.2f\n", menor);
	if (qtdMulher > 0) {
		printf("Media altura das mulheres: %.2f\n", somaMulher / qtdMulher);
	} else {
		printf("Nao teve mulher\n");
	}
	printf("Media altura da turma: %.2f\n", somaTudo / 50);
	return 0;
}
