#include <stdio.h>

int main() {
    int idade;
    char sexo;
    float salario;
    int qtdMulher = 0;
    int somaIdade = 0;
    int qtdPessoas = 0;
    float somaSalario = 0;
    int maiorIdade = 0;
    int menorIdade = 1000;

    do {
        printf("Digite a idade (ou um número negativo para sair): ");
        scanf("%d", &idade);
        
        if (idade < 0) break;

        printf("Digite o sexo (M/F): ");
        scanf(" %c", &sexo);
        
        printf("Digite o salário: ");
        scanf("%f", &salario);
        
        qtdPessoas++;
        somaIdade += idade;
        somaSalario += salario;

        if (idade > maiorIdade) maiorIdade = idade;
        if (idade < menorIdade) menorIdade = idade;

        if ((sexo == 'F' || sexo == 'f') && salario <= 100) {
            qtdMulher++;
        }
    } while (1);

    if (qtdPessoas > 0) {
        printf("Média de salário: %.2f\n", somaSalario / qtdPessoas);
        printf("Maior idade: %d\n", maiorIdade);
        printf("Menor idade: %d\n", menorIdade);
        printf("Quantidade de mulheres com salário até R$100,00: %d\n", qtdMulher);
    } else {
        printf("Nenhuma pessoa registrada.\n");
    }

    return 0;
}
