#include <stdio.h>
int main() {
	int m;
	int i;
	printf("Digite numeros positivos (0 ou negativo para parar):\n");
	while (1) {
		printf("Digite m: ");
		scanf("%d", &m);
		if (m <= 0) {
			break;
		}
		if (m % 2 == 0) {
			int countDiv = 0;
			for (i = 1; i <= m; i++) {
				if (m % i == 0) {
					countDiv = countDiv + 1;
				}
			}
			printf("Numero %d e par e tem %d divisores.\n\n", m, countDiv);
		} else {
			if (m < 10) {
				int fat = 1;
				for (i = 1; i <= m; i++) {
					fat = fat * i;
				}
				printf("Numero %d e impar e menor que 10. Fatorial = %d\n\n", m, fat);
			} else {
				int soma = 0;
				for (i = 1; i <= m; i++) {
					soma = soma + i;
				}
				printf("Numero %d e impar e maior ou igual a 10. Soma de 1 ate %d = %d\n\n", m, m, soma);
			}
		}
	}
	printf("Fim do programa.\n");
	return 0;
}