#include <stdio.h>
int main() {
	int N, i, num, j, fatorial;
	printf("Quantos valores vai ler? ");
	scanf("%d", &N);
	for (i = 1; i <= N; i++) {
		printf("Digite o valor %d: ", i);
		scanf("%d", &num);
		fatorial = 1;
		for (j = 1; j <= num; j++) {
			fatorial = fatorial * j;
		}
		printf("Valor: %d Fatorial: %d\n", num, fatorial);
	}
	return 0;
}
