#include <stdio.h>


int main() {
	int i;
	int valor;
	int numNegativos = 0;
	for (i = 1; i <= 5; i++) {
		printf("Digite o valor %d: ", i);
		scanf("%d", &valor);
		if (valor < 0) {
			numNegativos = numNegativos + 1;
		}
	}
	printf("Foram digitados %d valores negativos.\n", numNegativos);
	return 0;
}
