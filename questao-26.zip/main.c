#include <stdio.h>

int main() {
    int num = 1000;
    
    while (num <= 1999) {
        if (num % 11 == 5) {
            printf("%d\n", num);
        }
        num++;
    }
    
    return 0;
}
