#include <stdio.h>
int main() {
	int num;
	int produto = 1;
	int temPar = 0;
	scanf("%d", &num);
	while (num != 0) {
		if (num > 0) {
			if (num % 2 == 0) {
				produto = produto * num;
				temPar = 1;
			}
		}
		scanf("%d", &num);
	}
	if (temPar == 1) {
		printf("%d\n", produto);
	} else {
		printf("Nenhum numero par foi digitado.\n");
	}
	return 0;
}
