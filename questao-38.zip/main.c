
#include <stdio.h>

int main() {
    int num, i, div;
    int produto = 1;
    int inicio = 92;
    int fim = 1478;

    num = inicio;
    while (num <= fim) {
        div = 0;
        for (i = 1; i <= num; i++) {
            if (num % i == 0) {
                div++;
            }
        }
        
        if (div == 2) {
            produto *= num;
            printf("%d ", num);
        }
        num++;
    }
    
    printf("\nProduto dos primos: %d\n", produto);
    return 0;
}

