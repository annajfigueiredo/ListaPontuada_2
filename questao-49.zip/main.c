#include <stdio.h>
int main() {
	int N, i;
	int fatorial = 1;
	printf("Digite um numero inteiro e positivo: ");
	scanf("%d", &N);
	if (N < 0) {
		printf("Numero invalido! Digite um inteiro positivo.\n");
	} else {
		for (i = 1; i <= N; i++) {
			fatorial = fatorial * i;
		}
		printf("Fatorial de %d = %d\n", N, fatorial);
	}
	return 0;
}
