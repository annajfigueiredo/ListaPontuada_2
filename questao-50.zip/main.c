#include <stdio.h>
int main() {
	int X, Y;
	int resultado = 1;
	int i;
	do {
		printf("Digite o valor de X: ");
		scanf("%d", &X);
		printf("Digite o valor de Y: ");
		scanf("%d", &Y);
		if (X < 0 || Y < 0) {
			printf("Valores invalidos! Digite apenas inteiros positivos.\n\n");
		}
	} while (X < 0 || Y < 0);
	for (i = 1; i <= Y; i++) {
		resultado = resultado * X;
	}
	printf("%d elevado a %d = %d\n", X, Y, resultado);
	return 0;
}
