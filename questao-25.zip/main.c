#include <stdio.h>

int main() {
    int codigo;
    float preco, precoNovo;
    float somaPreco = 0, somaPrecoNovo = 0;
    int qtd = 0;

    while (1) {
        scanf("%d", &codigo);
        if (codigo < 0) break;
        scanf("%f", &preco);
        
        precoNovo = preco * 1.20;
        printf("%d %.2f\n", codigo, precoNovo);
        
        somaPreco += preco;
        somaPrecoNovo += precoNovo;
        qtd++;
    }

    if (qtd > 0) {
        printf("Média sem aumento: %.2f\n", somaPreco / qtd);
        printf("Média com aumento: %.2f\n", somaPrecoNovo / qtd);
    }

    return 0;
}
