#include <stdio.h>

int fatorial(int n) {
    int resultado = 1;
    for (int i = 1; i <= n; i++) {
        resultado *= i;
    }
    return resultado;
}

int main() {
    int N, P;

    do {
        printf("Digite um valor para N (maior que zero): ");
        scanf("%d", &N);
        printf("Digite um valor para P (0 <= P <= N): ");
        scanf("%d", &P);
        if (N <= 0 || P < 0 || P > N) {
            printf("Valores invalidos. Tente novamente.\n\n");
        }
    } while (N <= 0 || P < 0 || P > N);

    int fatorialN = fatorial(N);
    int fatorialP = fatorial(P);
    int fatorialNP = fatorial(N - P);

    int arranjo = fatorialN / fatorialNP;
    int combinacao = fatorialN / (fatorialP * fatorialNP);

    printf("\nArranjo de %d elementos em subconjuntos de %d = %d\n", N, P, arranjo);
    printf("Combinacao de %d elementos em subconjuntos de %d = %d\n", N, P, combinacao);

    return 0;
}
